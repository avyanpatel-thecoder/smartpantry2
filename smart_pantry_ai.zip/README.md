# Smart Pantry AI

Responsive pantry app using Flask, SQLite, Open Food Facts, html5-qrcode, and Groq AI.

## Run locally
Python 3.10+:
```bash
python -m venv .venv
# Windows PowerShell: .venv\Scripts\Activate.ps1
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
python app.py
```
Visit http://127.0.0.1:5000. Barcode camera access works on localhost or HTTPS.

## Deploy on Render
1. Upload the files to a GitHub repository, keeping `templates/` and `static/`.
2. In Render choose **New + → Blueprint** and connect the repository. Render reads `render.yaml`.
3. The blueprint configures a persistent disk for SQLite and generates `SECRET_KEY`.
4. In Render Environment, add `GROQ_API_KEY` with your private key and keep it secret. Do not put API keys in GitHub.
5. Deploy and test account creation, manual entry, barcode lookup, and recipes.

## Groq AI
This app expects a Groq API key and uses the OpenAI-compatible Groq chat completions endpoint. Set:
- `GROQ_API_KEY`: your Groq secret key
- `GROQ_MODEL`: default `llama-3.3-70b-versatile`

If the key you shared in chat is real, revoke it and create a new one in your Groq console. Add the replacement only to Render's environment variables, never to source code or GitHub.

## Notes before sharing widely
Open Food Facts coverage varies; manual entry is the fallback. This is a working starter, not a security-audited large-scale service. Before a large public launch, add rate limiting, CSRF protections, email verification, password reset/account deletion, monitoring and database backups. SQLite on a single Render persistent disk is fine for an initial small deployment, but managed PostgreSQL is a better choice for scaling to many users. Verify current Groq and Open Food Facts terms/rate limits before public launch.
