import os, re, sqlite3, json
from functools import wraps
import requests
from flask import Flask, jsonify, render_template, request, session
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "change-this-before-deploying")
DB_PATH = os.environ.get("DATABASE_PATH", "smart_pantry.db")
GROQ_API_KEY = os.environ.get("GROQ_API_KEY", "")
GROQ_MODEL = os.environ.get("GROQ_MODEL", "llama-3.3-70b-versatile")

def connect():
    if os.path.dirname(DB_PATH):
        os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    c = sqlite3.connect(DB_PATH, timeout=20)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA foreign_keys=ON")
    return c

def init_db():
    with connect() as db:
        db.executescript("""
        CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, email TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS pantry_items(
          id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL, barcode TEXT DEFAULT '', name TEXT NOT NULL,
          brand TEXT DEFAULT '', quantity REAL NOT NULL DEFAULT 1, unit TEXT NOT NULL DEFAULT 'item',
          category TEXT DEFAULT '', image_url TEXT DEFAULT '', created_at TEXT DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE);
        CREATE INDEX IF NOT EXISTS idx_pantry_user ON pantry_items(user_id);
        """)
init_db()

def logged_in(fn):
    @wraps(fn)
    def inner(*a, **kw):
        if not session.get("user_id"): return jsonify({"error":"Please sign in again."}),401
        return fn(*a, **kw)
    return inner

@app.after_request
def headers(r):
    r.headers["X-Content-Type-Options"]="nosniff"
    r.headers["X-Frame-Options"]="DENY"
    r.headers["Referrer-Policy"]="strict-origin-when-cross-origin"
    r.headers["Permissions-Policy"]="camera=(self)"
    return r

@app.get("/")
def home():
    return render_template("index.html", email=session.get("email","")) if session.get("user_id") else render_template("auth.html")
@app.get("/health")
def health(): return jsonify({"ok":True})

@app.post("/api/register")
def register():
    d=request.get_json(silent=True) or {}; email=str(d.get("email","")).strip().lower(); password=str(d.get("password",""))
    if not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+",email): return jsonify({"error":"Enter a valid email address."}),400
    if len(password)<8: return jsonify({"error":"Password must be at least 8 characters."}),400
    try:
        with connect() as db: uid=db.execute("INSERT INTO users(email,password_hash) VALUES(?,?)",(email,generate_password_hash(password))).lastrowid
        session.clear(); session["user_id"]=uid; session["email"]=email
        return jsonify({"ok":True})
    except sqlite3.IntegrityError: return jsonify({"error":"That email already exists. Please sign in."}),409

@app.post("/api/login")
def login():
    d=request.get_json(silent=True) or {}; email=str(d.get("email","")).strip().lower()
    with connect() as db: u=db.execute("SELECT * FROM users WHERE email=?",(email,)).fetchone()
    if not u or not check_password_hash(u["password_hash"],str(d.get("password",""))): return jsonify({"error":"Email or password is incorrect."}),401
    session.clear(); session["user_id"]=u["id"]; session["email"]=u["email"]
    return jsonify({"ok":True})
@app.post("/api/logout")
def logout(): session.clear(); return jsonify({"ok":True})

@app.get("/api/pantry")
@logged_in
def get_pantry():
    with connect() as db: rows=db.execute("SELECT id,barcode,name,brand,quantity,unit,category,image_url,created_at FROM pantry_items WHERE user_id=? ORDER BY name COLLATE NOCASE",(session["user_id"],)).fetchall()
    return jsonify([dict(x) for x in rows])

@app.post("/api/pantry")
@logged_in
def add_pantry():
    d=request.get_json(silent=True) or {}; name=str(d.get("name","")).strip()
    if not name or len(name)>120: return jsonify({"error":"Enter a food name (up to 120 characters)."}),400
    try: q=float(d.get("quantity",1))
    except (ValueError,TypeError): return jsonify({"error":"Quantity must be a number."}),400
    if not 0<q<=100000: return jsonify({"error":"Quantity must be greater than zero."}),400
    vals=(session["user_id"],str(d.get("barcode",""))[:40],name,str(d.get("brand",""))[:120],q,str(d.get("unit","item"))[:24] or "item",str(d.get("category",""))[:80],str(d.get("image_url",""))[:500])
    with connect() as db:
        i=db.execute("INSERT INTO pantry_items(user_id,barcode,name,brand,quantity,unit,category,image_url) VALUES(?,?,?,?,?,?,?,?)",vals).lastrowid
        row=db.execute("SELECT id,barcode,name,brand,quantity,unit,category,image_url,created_at FROM pantry_items WHERE id=?",(i,)).fetchone()
    return jsonify(dict(row)),201

@app.patch("/api/pantry/<int:item_id>")
@logged_in
def update_pantry(item_id):
    try: q=float((request.get_json(silent=True) or {}).get("quantity"))
    except (ValueError,TypeError): return jsonify({"error":"Quantity must be a number."}),400
    if q<0 or q>100000: return jsonify({"error":"Quantity must be between 0 and 100000."}),400
    with connect() as db:
        exists=db.execute("SELECT id FROM pantry_items WHERE id=? AND user_id=?",(item_id,session["user_id"])).fetchone()
        if not exists: return jsonify({"error":"Item not found."}),404
        if q==0:
            db.execute("DELETE FROM pantry_items WHERE id=? AND user_id=?",(item_id,session["user_id"])); return jsonify({"deleted":True})
        db.execute("UPDATE pantry_items SET quantity=? WHERE id=? AND user_id=?",(q,item_id,session["user_id"]))
        row=db.execute("SELECT id,barcode,name,brand,quantity,unit,category,image_url,created_at FROM pantry_items WHERE id=?",(item_id,)).fetchone()
    return jsonify(dict(row))
@app.delete("/api/pantry/<int:item_id>")
@logged_in
def delete_pantry(item_id):
    with connect() as db: c=db.execute("DELETE FROM pantry_items WHERE id=? AND user_id=?",(item_id,session["user_id"]))
    return (jsonify({"ok":True}) if c.rowcount else (jsonify({"error":"Item not found."}),404))

@app.get("/api/barcode/<path:barcode>")
@logged_in
def barcode(barcode):
    barcode=re.sub(r"\D","",barcode)
    if not 8<=len(barcode)<=14: return jsonify({"error":"That barcode number doesn't look valid."}),400
    try:
        r=requests.get(f"https://world.openfoodfacts.org/api/v2/product/{barcode}.json",headers={"User-Agent":"SmartPantryAI/1.0"},timeout=8); r.raise_for_status(); d=r.json()
    except (requests.RequestException,ValueError): return jsonify({"error":"Product lookup is temporarily unavailable. Add the food manually."}),502
    p=d.get("product") or {}
    name=(p.get("product_name") or p.get("product_name_en") or p.get("generic_name") or "").strip()
    if d.get("status")!=1 or not name: return jsonify({"found":False,"barcode":barcode,"message":"Product not found. Add its name manually."})
    cats=p.get("categories_tags") or []
    return jsonify({"found":True,"barcode":barcode,"name":name[:120],"brand":(p.get("brands") or "")[:120],"category":cats[0].replace("en:","").replace("-"," ")[:80] if cats else "","image_url":(p.get("image_front_small_url") or p.get("image_url") or "")[:500]})

@app.post("/api/recipes")
@logged_in
def recipes():
    if not GROQ_API_KEY:
        return jsonify({"configured":False,"message":"Add your Groq API key in Render as GROQ_API_KEY to turn on AI recipes."}),503
    with connect() as db: items=db.execute("SELECT name,quantity,unit FROM pantry_items WHERE user_id=? ORDER BY name",(session["user_id"],)).fetchall()
    if not items: return jsonify({"error":"Add a few ingredients to your pantry first."}),400
    ingredient_text=", ".join(f"{x['quantity']} {x['unit']} {x['name']}" for x in items)
    try:
        r=requests.post("https://api.groq.com/openai/v1/chat/completions",
          headers={"Authorization":f"Bearer {GROQ_API_KEY}","Content-Type":"application/json"},
          json={"model":GROQ_MODEL,"temperature":0.5,"messages":[
            {"role":"system","content":'You are a practical cooking assistant. Return valid JSON only in this shape: {"recipes":[{"name":"...","time":"...","description":"...","ingredients":["..."],"steps":["..."],"missing":["..."]}]}. Suggest up to 3 safe, realistic recipes.'},
            {"role":"user","content":f"Make up to 3 recipe ideas using these ingredients: {ingredient_text}. Prioritize available ingredients and list any missing items."}
          ]},timeout=35)
        r.raise_for_status(); content=r.json()["choices"][0]["message"]["content"].strip()
        content=re.sub(r"^```(?:json)?\s*|\s*```$","",content,flags=re.I)
        result=json.loads(content)
        if not isinstance(result.get("recipes"),list): raise ValueError("Unexpected format")
        return jsonify({"configured":True,"recipes":result["recipes"]})
    except (requests.RequestException,KeyError,ValueError,TypeError):
        app.logger.exception("Groq recipe call failed")
        return jsonify({"error":"The AI recipe service failed. Check your API key/model and try again."}),502

if __name__=="__main__": app.run(host="0.0.0.0",port=int(os.environ.get("PORT",5000)),debug=False)
